Title A2
Author @bisi0005@algonquinlive.com
covered the scope of the assignment 
Status
completed

Known Issues
None related to this scope.
Expected Grade
B+ to A+