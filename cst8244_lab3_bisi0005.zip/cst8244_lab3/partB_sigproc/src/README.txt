Sig processing &interrupt

status: done

This project consists of  a functions that will demostrate a signal interrupt and processing using QNX RTOS

 the program runs as expected.
 There are no missing requirements as far as the lab specs go,
 when a SIGUSR1 is sent from the RTOS terminal, the ide will print the child process id and show that it was interrupted
 When all child processes die, the parent process will then exit.
 the user has an option of putting upto 10 child processes.
 
 There are no known issues involved within the scope of this lab.However i noticed that when the parent is killed
 while still having the child processes, they are also killed and the program terminates and the connection to the 
 QNX RTOS terminates.
 
 
 Expected grade : A+ as all specs defined in the lab were followed and satisfied.