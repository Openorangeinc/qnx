#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define true 1
#define false 0

void sigusr1_handler(int);
sig_atomic_t usr1Happened = false;

int main(void) {
	struct sigaction Sigusr1;

	Sigusr1.sa_handler = sigusr1_handler;

	Sigusr1.sa_flags = 0; /* or SA_RESTART */

	sigemptyset(&Sigusr1.sa_mask); //blocked sigs =no signals
	if (sigaction(SIGUSR1, &Sigusr1, NULL) == -1) {

				perror("sig action at sigusr1 returned -1");
				exit(1);
	}
	//child processes to fork
	int children;
	printf("Enter the number of children: \n");
	scanf("%d", &children);

	printf("PID = %d: Parent process running...\n", getpid());//pp isnt p

	pid_t pids[255]; // 255 pids max  mostly 0s if created
	int temp;
	//forking
	for (int i = 0; i < children; ++i) {
		// Handle error if fork() ==-1 then failed
	  if ((pids[i] = fork()) < 0) {
	    perror("error occurred while creating a child process");
	    abort();
	  }

	  else if (pids[i] == 0) {
		  printf("PID = %d: Child running...\n", getpid());
		  scanf("%d", &temp); //pause from exiting
		  exit(0); //return to Ppid
	  }
	}

	int status; //wait for children to die

	while (children > 0) {
	  wait(&status);
	  --children;
	}

	printf("Children finished,Parent exiting");
	exit(-1);
}

// like part A
//*param s is the pid interrupted
void sigusr1_handler(int s) {
	usr1Happened = true;
	printf("\nPID = %d: Child received USR1 sig.", getpid());
	printf("\nPID = %d: Child Exiting.\n", getpid());
}

