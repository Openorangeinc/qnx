Sig interrupt

status: done

This project consists of  a functions that will demostrate a signal interrupt using QNX RTOS

 the program runs as expected.
 There are no missing requirements as far as the lab specs go,
 when a SIGUSR1 is sent from the RTOS terminal, the ide will print the id and show that it was interrupted
 
 There are no known issues involved within the scope of this lab
 
 Expected grade : A+ as all specs defined in the lab were followed and satisfied.