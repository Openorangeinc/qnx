#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>


#define false 0
#define true 1

//signal receiver
sig_atomic_t usr1Happened =0;


//fn declarations
void sig_action_happened(int);




//sig handler to set  the user1_happened to true 1
//@param s is the pid that gets interrupted
void sig_action_happened(int s){
	// set atomic sig to true
	usr1Happened= 1;
	printf(	"PID : %d received USR1\n",getpid());
	printf("PID : %d running\n ",getpid());
	printf("PID : %d exiting ",getpid());
	puts("interrupt happened "); // was curious about the param meaning
	printf("id %d",s);
}
int main(void) {
	//puts("Hello World!!!"); /* prints Hello World!!! */
		puts("lab 3 running");
	struct sigaction usr1;
	usr1.sa_handler = sig_action_happened; /* Setting the handler for SIGUSR1 */
	usr1.sa_flags = 0; // or SA_RESTART
	sigemptyset(&usr1.sa_mask);

	//loop
	while(usr1Happened == 0){
		//listen to the results at sigemptyset
		if(sigaction(SIGUSR1,&usr1,NULL)==-1){
			perror("sig action at sigusr1 returned -1");
			exit(1);
		}
	}
	return EXIT_SUCCESS;
}



