bisi0005

A1

status: done

This assignment run properly with some minor issues where it freezes during input 
but this caused be cause by the low mwmory on my machine

expected grade B+

known issues:
	some times it freezes and i have to terminate the application